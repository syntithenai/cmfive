<?php

namespace ClassesWithParents;

class B implements CInterface {}
