<?php

class Apc_Pearlike_Baz
{
    public static $loaded = true;
}
