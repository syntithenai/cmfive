<?php

class Pearlike2_FooBar
{
    public static $loaded = true;
}
