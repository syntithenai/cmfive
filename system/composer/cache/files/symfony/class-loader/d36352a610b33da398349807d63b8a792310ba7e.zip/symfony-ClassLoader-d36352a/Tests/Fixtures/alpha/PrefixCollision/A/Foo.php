<?php

class PrefixCollision_A_Foo
{
    public static $loaded = true;
}
