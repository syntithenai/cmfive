<?php

use Phinx\Migration\AbstractMigration;

class DuplicateMigration2 extends AbstractMigration
{
    /**
     * Migrate Up.
     */
    public function up()
    {
        // do nothing
    }

    /**
     * Migrate Down.
     */
    public function down()
    {
        // do nothing
    }
}
