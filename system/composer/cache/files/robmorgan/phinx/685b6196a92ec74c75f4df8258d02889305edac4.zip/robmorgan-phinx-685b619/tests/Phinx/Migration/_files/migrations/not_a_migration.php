<?php

echo 'I shouldnt be run';
