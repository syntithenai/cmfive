<?php
namespace Codeception\PHPUnit;

class DummyCodeCoverage extends \PHP_CodeCoverage
{
    public function start($id, $clear = FALSE)
    {

    }

    function stop($append = TRUE)
    {

    }
}
