<?php
$I = new SkipGuy($scenario);
$I->wantTo('talk, just talk');
$I->am('very lazy qa');
$I->lookForwardTo('not do anything at all');
$I['have a comment for you'];
$I['but I am too lazy to do any job'];
$I['so please do that yourself'];
$I->amGoingTo('leave that to you');
$I->expect('you forgive me');