<?php
namespace Jazz\Pianist;

class BillEvans
{
    public static function add($a, $b)
    {
        return $a + $b;
    }
}
