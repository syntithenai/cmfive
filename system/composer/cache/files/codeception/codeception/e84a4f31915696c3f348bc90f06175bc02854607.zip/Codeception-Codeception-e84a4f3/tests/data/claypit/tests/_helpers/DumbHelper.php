<?php
namespace Codeception\Module;

// here you can define custom functions for DumbGuy 

class DumbHelper extends \Codeception\Module
{
}
