<?php
class DocBlox_Plugin_Codeception_Exception extends Exception
{
}