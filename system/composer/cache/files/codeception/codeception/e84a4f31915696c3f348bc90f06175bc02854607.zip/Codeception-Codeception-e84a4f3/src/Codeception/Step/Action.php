<?php
namespace Codeception\Step;
 
class Action extends \Codeception\Step {
}
