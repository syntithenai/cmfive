<?php
namespace Jazz;

class Musician
{
    public static function add($a, $b)
    {
        return $a + $b;
    }
}
