<?php
namespace Codeception\Step;
 
class Condition extends \Codeception\Step {
}
