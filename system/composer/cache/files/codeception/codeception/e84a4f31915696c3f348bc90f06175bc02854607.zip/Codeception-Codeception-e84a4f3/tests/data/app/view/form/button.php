<html>
<body>
<form action="/form/button" method="POST">
    <input type="hidden" name="text" value="val" />
    <button type="submit">Submit</button>
</form>
</body>
</html>